package MavenProject.Z_14_Employee_mangment;




import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import java.util.List;

public class EmployeeDAO {
    private static SessionFactory factory = new Configuration().configure().buildSessionFactory();

    // Add employee
    public void addEmployee(Employee emp) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(emp);
        tx.commit();
        session.close();
        System.out.println("Employee added: " + emp);
    }

    // Update salary
    public void updateSalary(int id, double newSalary) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        String hql = "update Employee set salary = :salary where id = :id";
        Query<?> query = session.createQuery(hql);
        query.setParameter("salary", newSalary);
        query.setParameter("id", id);
        int result = query.executeUpdate();
        tx.commit();
        session.close();
        System.out.println("Updated " + result + " record(s)");
    }

    // Delete employee
    public void deleteEmployee(int id) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        String hql = "delete from Employee where id = :id";
        Query<?> query = session.createQuery(hql);
        query.setParameter("id", id);
        int result = query.executeUpdate();
        tx.commit();
        session.close();
        System.out.println("Deleted " + result + " record(s)");
    }

    // Get all employees
    public void getAllEmployees() {
        Session session = factory.openSession();
        String hql = "from Employee";
        List<Employee> list = session.createQuery(hql, Employee.class).list();
        for (Employee e : list) {
            System.out.println(e);
        }
        session.close();
    }

    // Get employee by ID
    public void getEmployeeById(int id) {
        Session session = factory.openSession();
        String hql = "from Employee where id = :id";
        Query<Employee> query = session.createQuery(hql, Employee.class);
        query.setParameter("id", id);
        Employee emp = query.uniqueResult();
        System.out.println(emp);
        session.close();
    }

    // MAIN METHOD
    public static void main(String[] args) {
    	EmployeeDAO dao = new EmployeeDAO();

        // Add Employees
        dao.addEmployee(new Employee("Shivam", "IT", 45000));
        dao.addEmployee(new Employee("Ajay", "HR", 35000));

        // Read All
        System.out.println("All Employees:");
        dao.getAllEmployees();

        // Update
        dao.updateSalary(1, 50000);

        // Read One
        System.out.println("Employee with ID 1:");
        dao.getEmployeeById(1);

        // Delete
        dao.deleteEmployee(2);

        // Final List
        System.out.println("Final Employee List:");
        dao.getAllEmployees();
    }
}
