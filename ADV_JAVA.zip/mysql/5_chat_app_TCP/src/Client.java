
import java.io.*;
import java.net.*;
import java.util.*;
public class Client {
	
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
        Socket s = new Socket("localhost",6000);
		
		DataOutputStream dout = new DataOutputStream(s.getOutputStream());
		DataInputStream din = new DataInputStream(s.getInputStream());
		String str = " ";
		String str2 = " ";
		
		while(str != "stop") {
		//System.out.print("Me: ");
	    str = sc.nextLine();
		dout.writeUTF(str);
		dout.flush();
		
	    str2 = (String)din.readUTF();
		System.out.println("Server :" + str2);
     }

}
}