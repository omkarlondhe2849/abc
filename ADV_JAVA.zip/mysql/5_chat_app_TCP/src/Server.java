
import java.io.*;
import java.util.*;
import java.net.*;

public class Server {
	
	 public static void main(String[] args) throws IOException 
	 {
		 Scanner sc = new Scanner(System.in);
		 
		  ServerSocket s = new ServerSocket(6000);
		  
		  Socket ss = s.accept();
		  
		  DataInputStream din = new DataInputStream(ss.getInputStream());
		  DataOutputStream dout = new DataOutputStream(ss.getOutputStream());
		  
		  String str = " ";
		  String str2 = " ";
		  while(str != "stop")
		  {
		  str = din.readUTF();
		  System.out.println("Client :" + str);
		  
		 // System.out.print("me: ");
		  str2 = sc.nextLine();
		  dout.writeUTF(str2);
		  dout.flush();
		   }
		
		  
		  
		 
	 }

}