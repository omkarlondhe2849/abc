package MavenProject.Mit;

import org.hibernate.*;
import org.hibernate.boot.*;
import org.hibernate.boot.registry.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernet.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        // Store data
        Department it = new Department("IT");
        Department hr = new Department("HR");

        Employee e1 = new Employee("Shivam", 45000, it);
        Employee e2 = new Employee("Yash", 40000, it);
        Employee e3 = new Employee("Tanuj", 30000, hr);

        session.save(it);
        session.save(hr);
        session.save(e1);
        session.save(e2);
        session.save(e3);

        // Basic Join HQL
        System.out.println("\n--- Employees with Departments ---");
        List<Object[]> joinList = session.createQuery(
            "SELECT e.name, e.salary, d.name FROM Employee e JOIN e.department d", Object[].class
        ).getResultList();

        for (Object[] row : joinList) {
            System.out.println("Name: " + row[0] + ", Salary: " + row[1] + ", Dept: " + row[2]);
        }

        // Aggregation (Average salary per department)
        System.out.println("\n--- Avg Salary by Department ---");
        List<Object[]> avgList = session.createQuery(
            "SELECT d.name, AVG(e.salary) FROM Employee e JOIN e.department d GROUP BY d.name", Object[].class
        ).getResultList();

        for (Object[] row : avgList) {
            System.out.println("Department: " + row[0] + ", Avg Salary: " + row[1]);
        }

        tx.commit();
        session.close();
        factory.close();
    }
}
