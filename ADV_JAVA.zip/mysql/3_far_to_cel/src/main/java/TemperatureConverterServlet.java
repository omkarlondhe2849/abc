import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;

public class TemperatureConverterServlet extends GenericServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    public void service(ServletRequest request, ServletResponse response) 
            throws ServletException, IOException {

        // Set the content type to HTML
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Read the 'celsius' parameter from the request
            String celsiusInput = request.getParameter("celsius");

            // Check if input is provided
            if (celsiusInput == null || celsiusInput.trim().isEmpty()) {
                out.println("<h3>Please enter a temperature value in Celsius.</h3>");
                return;
            }

            // Convert input string to double
            double celsius = Double.parseDouble(celsiusInput.trim());

            // Perform the conversion
            double fahrenheit = (celsius * 9 / 5) + 32;

            // Display the result
            out.println("<html>");
            out.println("<head><title>Temperature Converter</title></head>");
            out.println("<body>");
            out.println("<h2>Celsius to Fahrenheit Converter</h2>");
            out.println("<p>" + celsius + " &deg;C is equal to " + fahrenheit + " &deg;F</p>");
            out.println("</body>");
            out.println("</html>");

        } catch (NumberFormatException e) {
            out.println("<h3>Invalid input! Please enter a valid numeric value.</h3>");
        } finally {
            out.close();
        }
    }
}
