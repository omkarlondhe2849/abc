import javax.servlet.*;
import java.io.*;

public class FServlet extends GenericServlet{
	
	public void service(ServletRequest req,ServletResponse res) throws ServletException , IOException
	{
		res.setContentType("text/html");
		
		PrintWriter pw = res.getWriter();
		
	      String a = req.getParameter("c");
	      
	      int x = Integer.parseInt(a);
	      
	       x = x*(9/5)+32;
	       
	       pw.println("F:"+x);
	      
	      
		
	}

}