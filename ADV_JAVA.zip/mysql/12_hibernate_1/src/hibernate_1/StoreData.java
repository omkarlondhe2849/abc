package hibernate_1;



import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class StoreData {

	public static void main(String[] args) {
		
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		
		Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory fac = md .getSessionFactoryBuilder().build();
		
		Session sec = fac.openSession();
		
		Transaction t = sec.beginTransaction();
		
		Employee e = new Employee();
		
		e.setId(100);
		e.setName("phone");
		
		sec.save(e);
		t.commit();
		fac.close();
		sec.close();
		System.out.println("saved......");
		
		
	}
}
