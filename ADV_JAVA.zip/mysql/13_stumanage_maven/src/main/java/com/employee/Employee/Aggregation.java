package com.employee.Employee;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Aggregation {

    public static void main(String[] args) {
        // Setup Hibernate
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory fac = md.getSessionFactoryBuilder().build();
        Session sess = fac.openSession();
        Transaction t = sess.beginTransaction();

        // Correct SELECT query with getSingleResult
        String query1 = "select sum(e.id) from Student e";
        Query q1 = sess.createQuery(query1);

        Long sumId = (Long) q1.getSingleResult();
        System.out.println("Sum of Ids: " + sumId);
        
        // Correct SELECT query with getSingleResult
        String query2 = "select avg(e.id) from Student e";
        Query q2 = sess.createQuery(query2);

        Double avgId = (Double) q2.getSingleResult();
        System.out.println("Sum of Ids: " + avgId);
        
        

        
        
        t.commit();
        sess.close();
        fac.close();
    }
}
