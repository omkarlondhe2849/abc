package com.employee.Employee;


import org.hibernate.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class StoreData {

	
	public static void main(String[] args) {
		
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		
		Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory fac =  md.getSessionFactoryBuilder().build();
		
		Session sess = fac.openSession();
		
		Transaction t = sess.beginTransaction();
		
		Student e = new Student();
		
		e.setId(5);
		e.setName("Mitesh");
		
		sess.save(e);
		t.commit();
		fac.close();
		sess.close();
		
		System.out.println("SAvedd");
		
		
		
	}
}
