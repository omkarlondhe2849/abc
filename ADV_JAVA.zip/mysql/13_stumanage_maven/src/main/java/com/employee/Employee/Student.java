package com.employee.Employee;

import javax.persistence.*;

@Entity
@Table(name = "Student")
public class Student {
 
	@Id
	int Id;
	String Name;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	
}
