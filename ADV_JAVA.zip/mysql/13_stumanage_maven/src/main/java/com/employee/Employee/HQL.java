package com.employee.Employee;

import java.util.List;
import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import javax.persistence.Query;

public class HQL {

    public static void main(String[] args) {
        // Setup Hibernate
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory fac = md.getSessionFactoryBuilder().build();
        Session sess = fac.openSession();
        Transaction t = sess.beginTransaction();

        // Select query
        String query1 = "from Student as e where e.id = :empid";
        Query q1 = sess.createQuery(query1);
        q1.setParameter("stuid", 1);

        List<Student> list = q1.getResultList();
        for (Student e : list) {
            System.out.println(e.Id);
            System.out.println(e.Name);
        }

        // Update query
        String query2 = "update Student as e set e.Name = :newname where e.id = :empid";
        Query q2 = sess.createQuery(query2);
        q2.setParameter("newname", "Prasad");
        q2.setParameter("empid", 3);
        int r1 = q2.executeUpdate();

        // Delete query
        String query3 = "delete from Student e where e.id = :empid";
        Query q3 = sess.createQuery(query3);
        q3.setParameter("empid", 2);
        int r2 = q3.executeUpdate();

        // Commit transaction
        t.commit();

        System.out.println("Deleted: " + r2);
        System.out.println("Updated: " + r1);

        sess.close();
        fac.close();
    }
}
