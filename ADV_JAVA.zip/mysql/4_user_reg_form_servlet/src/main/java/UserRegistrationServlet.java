import java.io.*;
import javax.servlet.*;

public class UserRegistrationServlet extends GenericServlet {

    // Overriding the service method to handle POST request
    @Override
    public void service(ServletRequest request, ServletResponse response) 
            throws ServletException, IOException {

        // Set content type to HTML for the response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve user input from the form
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        // Basic validation to ensure no field is empty
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty() || 
            email == null || email.trim().isEmpty()) {
            
            out.println("<h3 style='color: red;'>Error: All fields are required. Please try again.</h3>");
            return;  // Stop processing if any field is missing
        }

        // Simple "success" message for now (In real apps, you would save this to a database)
        out.println("<html>");
        out.println("<head><title>Registration Successful</title></head>");
        out.println("<body>");
        out.println("<h2>Welcome, " + username + "!</h2>");
        out.println("<p>Your registration is successful.</p>");
        out.println("<p><strong>Email:</strong> " + email + "</p>");
        out.println("<p><a href='register.html'>Back to Registration</a></p>");
        out.println("</body>");
        out.println("</html>");

        // Close the PrintWriter stream
        out.close();
    }
}
