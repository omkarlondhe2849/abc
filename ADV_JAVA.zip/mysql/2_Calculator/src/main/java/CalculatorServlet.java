import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CalculatorServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Set the response content type to HTML
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Fetch input values from the form
            String num1Str = request.getParameter("num1");
            String num2Str = request.getParameter("num2");
            String operation = request.getParameter("operation");

            // Parse numbers
            double num1 = Double.parseDouble(num1Str);
            double num2 = Double.parseDouble(num2Str);
            double result = 0.0;

            // Perform the selected operation
            switch (operation) {
                case "add":
                    result = num1 + num2;
                    break;
                case "sub":
                    result = num1 - num2;
                    break;
                case "mul":
                    result = num1 * num2;
                    break;
                case "div":
                    if (num2 == 0) {
                        out.println("<h3>Error: Cannot divide by zero!</h3>");
                        return;
                    }
                    result = num1 / num2;
                    break;
                default:
                    out.println("<h3>Error: Invalid operation selected!</h3>");
                    return;
            }

            // Show the result
            out.println("<html><body>");
            out.println("<h2>Calculator Result</h2>");
            out.println("<p><strong>Result: </strong>" + result + "</p>");
            out.println("</body></html>");

        } catch (NumberFormatException e) {
            out.println("<h3>Error: Please enter valid numbers!</h3>");
        } finally {
            out.close();
        }
    }
}
