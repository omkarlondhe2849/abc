package com.mit;


import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.*;

public class StoreData {
	
	public static void main(String[] args) {
		
		
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata mt = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory fac = mt.getSessionFactoryBuilder().build();
		Session sec = fac.openSession();
		Transaction t = sec.beginTransaction();
		
		Student s1 = new Student();
		Student s2 = new Student();
		
		s1.setName("Prasad");
		s1.setPRN(40064);
		s1.setRollNo(64);
		
		s2.setName("Suyash");
		s2.setPRN(40057);
		s2.setRollNo(61);
		
		sec.save(s1);
		sec.save(s2);
		
		t.commit();
		sec.close();
		fac.close();
		
		System.out.println("Saved !! ");
		
	}
	
}
