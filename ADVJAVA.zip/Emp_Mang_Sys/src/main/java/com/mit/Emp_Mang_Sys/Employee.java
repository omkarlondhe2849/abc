package com.mit.Emp_Mang_Sys;

import javax.persistence.*;

@Entity
@Table(name = "Emp20")
public class Employee {
	@Id
	int id;
	
	@Column(name = "First_Name")
	String Fname;
	
	@Column(name = "Last_Name")
	String Lname;
	
	@Column(name = "DepartMent")
	String Dept;
	
	Address ad;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		Dept = dept;
	}
	
}
