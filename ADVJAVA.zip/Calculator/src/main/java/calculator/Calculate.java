package calculator;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Calculate extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		
		int num1 = Integer.parseInt(req.getParameter("num1"));
		int num2 = Integer.parseInt(req.getParameter("num2"));
		char op = req.getParameter("op").charAt(0);
		
		if(op == '+') {
			pw.println("Addition is : " + (num1 + num2));
		}
		else if(op == '-') {
			pw.println("Substraction is : " + (num1 - num2));
		}
		
		
		pw.close();
	}
	
}
