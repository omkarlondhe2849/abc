package server;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Server {
		
	public static void main(String[] args) throws IOException {
		
		
		Scanner sc = new Scanner(System.in);
		
		DatagramSocket ds = new DatagramSocket(8080);
		
		byte buffer[] = new byte[1024];
		
		while(true) {
			
			DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
			
			ds.receive(dp);
			
			String Cmsg = new String( dp.getData() , 0 , dp.getLength() );
			System.out.println("Client Says :  " + Cmsg);
			
			if(Cmsg.equals("stop")) {
				System.out.println("Exiting !! ");
				break;
			}
			
			
			System.out.println("Server : ");
			String Smsg = sc.next();
			
			byte[] replyBuffer = Smsg.getBytes();
			
			InetAddress ipa = dp.getAddress();
			int port = dp.getPort();
			
			DatagramPacket send = new DatagramPacket(replyBuffer,replyBuffer.length , ipa , port);
			
			ds.send(send);
			
			if(Smsg.equals("stop")) {
				
				System.out.println("Exiting !!!");
				break;
				
			}
			
		}
		
		ds.close();
		sc.close();
	}
	
}
