package calculator;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class calculator extends HttpServlet {
protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
	
	res.setContentType("text/html");
	PrintWriter pw = res.getWriter();
	String n1 = req.getParameter("txt1");
	String n2 = req.getParameter("txt2");
	String op = req.getParameter("op");
	switch(op) {
	case "Add":
		int x= Integer.parseInt(n1);
		int y= Integer.parseInt(n2);
		int z= x+y;
		pw.println("The addition is="+z);
		break;
		
		
	case "Sub":
		int a= Integer.parseInt(n1);
		int b= Integer.parseInt(n2);
		int c= a-b;
		pw.println("The Substraction is="+c);
		break;
	
		default:
		{
			
			pw.println("Invalid Option");
		}
		
	}
	
}
}
