import java.io.PrintWriter;
import javax.servlet.*;

public class First extends GenericServlet {
	public void init() {
		System.out.println("Serverlet Intialised");
		
	}
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.print("Generic Servlet Invoked");
		
	}
public void destroy() {
	System.out.println("Servlet Destroyed");
	
}
}
